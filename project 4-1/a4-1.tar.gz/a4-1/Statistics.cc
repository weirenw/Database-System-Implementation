#include "Statistics.h"

#define FOR_MAP(first,second,map)\
	for(typeof((map).begin())  it = (map).begin(); it != (map).end(); it++){\
		typeof(it->first) & first = it->first;\
		typeof(it->second) & second = it->second;

#define FOR_SET(first,set)\
		for(typeof((set).begin()) it = (set).begin(); it != (set).end(); it++){\
			typeof(it->first) & first = it->first;

#define END_FOR }

		Statistics::Statistics()
		{
		}
		Statistics::Statistics(Statistics &copyMe)
		{
		}
		Statistics::~Statistics()
		{
		}

		void Statistics::AddRel(char *relName, int numTuples)
		{
			string rName(relName);
			if(relMap.find(rName) != relMap.end())
				relMap.erase(relMap.find(rName));
			rel r;
			r.numTul = numTuples;
			relMap.insert(pair<string, rel>(rName,r));
			set<string> relPar;
			relPar.insert(rName);
			relPartition.insert(pair<set<string>, double>(relPar,(double)numTuples));
		}
		void Statistics::AddAtt(char *relName, char *attName, int numDistincts)
		{
			string rName(relName);
			string aName(attName);
			rel& r = relMap[rName];
			if(r.att.find(aName) != r.att.end())
				r.att.erase(r.att.find(aName));
			r.att.insert(pair<string, double>(aName, numDistincts));

			//cout<<"r.att.size: "<< r.att.size()<<endl;
		}
		void Statistics::CopyRel(char *oldName, char *newName)
		{
			string rOldName(oldName);
			string rNewName(newName);
			rel rOld = relMap[rOldName];
			rel rNew;

			//copy rOld data to rNew
			rNew.numTul = rOld.numTul;
			for (map<string, double>::iterator it = rOld.att.begin(); it != rOld.att.end(); it++) {
				rNew.att.insert(pair<string, double>(it->first, it->second));
			}
			//insert rNew, delete rOld?
			relMap.insert(pair<string, rel>(rNewName, rNew));

			set<string> relNewPar;
			relNewPar.insert(rNewName);
			relPartition.insert(pair<set<string>, double>(relNewPar,(double)rNew.numTul));
		}

		void Statistics::Read(char *fromWhere)
		{
			ifstream in;
			in.open(fromWhere);
if(!in){
cout<<"read file doesn't exist"<<endl;
return;
}
			unsigned int relMapSize;
			in>>relMapSize;
			string rName;
			double rNumTul;
			string attName;
			double attNum;
			unsigned int rAttSize;
			while (relMapSize>0) {
				in>>rName>>rNumTul;
				AddRel(const_cast<char*> (rName.c_str()),rNumTul);
				in>>rAttSize;
				while (rAttSize>0) {
					in>>attName>>attNum;
					AddAtt(const_cast<char*> (rName.c_str()), const_cast<char*> (attName.c_str()), attNum);
					rAttSize--;
				}
				relMapSize--;
			}
			in.close();
		}

		void Statistics::Write(char *fromWhere)
		{
			ofstream out;
			out.open(fromWhere);
			out<<(unsigned int)relMap.size()<<endl;

			for(map<string,rel> :: iterator it = relMap.begin(); it != relMap.end(); it++){
				string rName = it->first;
				rel r = it->second;
				out<<rName<<endl;//relation name
				out<<r.numTul<<endl;//relation number tuples
				out<<(unsigned int)r.att.size()<<endl;//attribute size
				for (map<string,double> :: iterator itAtt = r.att.begin(); itAtt != r.att.end(); itAtt++) {
					string attName = itAtt->first;
					double attNum = itAtt->second;
					out<<attName<<endl;
					out<<attNum<<endl;
				}
			}
			out.close();
		}

		void  Statistics::Apply(struct AndList *parseTree, char *relNames[], int numToJoin)
		{
			struct AndList *cur = parseTree;
			while (cur != NULL) {
				struct OrList *curOr = cur->left;
				while (curOr != NULL) {
					struct ComparisonOp *cmpOp = curOr->left;
					if (cmpOp->code == 3) { //if compare is equal
						struct Operand *oLeft = cmpOp->left;
						struct Operand *oRight = cmpOp->right;
						if (oLeft->code == 4 && oRight->code ==4) { //both two operands are names this is join between two relations
							string attLeft(oLeft->value);
							string attRight(oRight->value);
							string relLName(getRel(const_cast<char*>(attLeft.c_str())));
							string relRName(getRel(const_cast<char*>(attRight.c_str())));
							if(relLName.compare("ERROR") == 0){
								cout<<"relLName is ERROR"<<endl;
							}
							else if(relRName.compare("ERROR") == 0){
								cout<<"relRName is ERROR"<<endl;
							}
							else{	//get left relation and right relation create new combined relation delete two old relations
								cout<<"creating combined relation"<<endl;
								rel relLeft = relMap[relLName];
								cout<<"relLName: "<<relLName<<endl;
								rel relRight = relMap[relRName];
								cout<<"relRName: "<<relRName<<endl;
							cout<<relRight.numTul<<endl;
								rel relCombine;
								//create a combined relation
								cout<<"relLeft numTul: "<<relLeft.numTul<<endl;
								cout<<"relRight numTul: "<<relRight.numTul<<endl;
								cout<<"max att: "<<max(relLeft.att[attLeft], relRight.att[attRight])<<endl;
								relCombine.numTul = Estimate(parseTree,relNames,numToJoin);
								cout<<"join relation numTul: "<<relCombine.numTul<<endl;
								InsertRel(relCombine, relLeft);
								InsertRel(relCombine,relRight);
								char * relCombineName = new char[200];
							
								sprintf(relCombineName, "%s|%s", const_cast<char*>(relLName.c_str()), const_cast<char*>(relRName.c_str()));
								string relCombineString(relCombineName);
								cout<<"join relation name: "<<relCombineString<<endl;
								cout<<"join relation numTul: "<<relCombine.numTul<<endl;
								//insert combined relation
								relMap.insert(pair<string, rel>(relCombineString,relCombine));
								cout<<"after insering"<<endl;
								//erase relLeft and relRight
								if(relMap.find(relLName)!=relMap.end()){

									relMap.erase(relMap.find(relLName));
									cout<<"======erase rel: "<<relLName<<endl;
								}
								else{
									cout<<"relMap didn't find L: "<<relLName<<endl;
								}
								if(relMap.find(relRName) != relMap.end()){

									relMap.erase(relMap.find(relRName));
									cout<<"======erase rel: "<<relRName<<endl;
								}
								else{
									cout<<"relMap didn't find R: "<<relRName<<endl; 
								}
								cout<<"after erasing"<<endl;	
							}
						}
					}
				curOr = curOr->rightOr;
				}
				cur = cur->rightAnd;
			}
			rel tmpr = relMap["supplied||partsupp"]; 
			cout<<"Apply supplied|partsupp numTul: "<<tmpr.numTul <<endl;
			
		}

		void Statistics::InsertRel(rel& relCombine, rel& tmpRel){
			for (map<string,double> :: iterator itAtt = tmpRel.att.begin(); itAtt != tmpRel.att.end(); itAtt++) {
				relCombine.att.insert(pair<string, double>(itAtt->first, itAtt->second));
			}
		}		

		double Statistics::Estimate(struct AndList *parseTree, char **relNames, int numToJoin)
		{
			/*
			rel tmpr = relMap["supplied||partsupp"]; 
			cout<<"supplied|partsupp numTul: "<<tmpr.numTul <<endl;
			for(map<string,double>:: iterator it = tmpr.att.begin();it!=tmpr.att.end();it++){
				cout<<it->first<<":::"<<it->second<<endl;
			}
			*/
			//between And, the estimate is and
			//between Or, the estimate is union
			struct AndList *cur = parseTree;
			double result = 1;
			double resultN = 1;
			set<string> relRcd;
			while (cur!= NULL) {
				struct OrList *curOr = cur->left;
				double numerator = 1.0;
				double denominator = 1.0;
				map<string,double> attDenominator;
				while(curOr != NULL){

					struct ComparisonOp *cmpOp= curOr->left;
					/*
					   cout<<"here"<<endl;
					   cout<<cmpOp->code<<endl;

					   cout<<"partsupp: "<<relMap["partsupp"].numTul<<endl; 
					   cout<<"supplier: "<<relMap["supplier"].numTul<<endl;	
					   cout<<"partsupp att size: "<<relMap["partsupp"].att.size()<<endl;
					   cout<<"supplier att size: "<<relMap["supplier"].att.size()<<endl;
					 */

					struct Operand *oLeft = cmpOp->left;
					struct Operand *oRight = cmpOp->right;
					//compare is less or more than, then estimate 1/3 number
					if (cmpOp->code == 1 || cmpOp->code == 2) {
						//if compare right is int double string not a name
						if (oRight->code==1 || oRight->code==2 || oRight->code==3) {

							string attLeft(oLeft->value);
							string relLName(getRel(const_cast<char*>(attLeft.c_str())));
							rel relLeft = relMap[relLName];
							if(relRcd.count(relLName) == 0){
								relRcd.insert(relLName); 
								numerator *= relLeft.numTul;
							}
							denominator *= (1.0-1.0/3.0);
							if(attDenominator.count(attLeft)==0) 
							attDenominator.insert(pair<string, double>(attLeft,1.0-1.0/3.0));
							else
							attDenominator[attLeft]-=1.0/3.0;
							denominator *= (1.0-1.0/3.0);
						}
					}
					//if compare is equal 
					if(cmpOp->code == 3){

						string attLeft(oLeft->value);
						string relLName(getRel(const_cast<char*> (attLeft.c_str())));
						//						cout<<"relLName: " << relLName<<endl;

						rel relLeft = relMap[relLName];
						if(relRcd.count(relLName) == 0){
							relRcd.insert(relLName); 
							numerator *= relLeft.numTul;
						}
						//right is int double string not a name 1/attSize
						if(oRight->code == 1 || oRight->code == 2 || oRight->code==3){
							//							cout<<"dominator before: "<< denominator<<endl;
							denominator *=  (1.0 - 1.0/relLeft.att[attLeft]);
							if(attDenominator.count(attLeft)==0) 
							attDenominator.insert(pair<string, double>(attLeft,1.0-1.0/relLeft.att[attLeft]));
							else
							attDenominator[attLeft]-=1.0/relLeft.att[attLeft];
							//							cout<<"dominator after: " <<denominator<<endl;
						}
						//compare is between to att  estimate 1/max(attleft,attright)
						if(oRight->code == 4){ 
							string attRight(oRight->value);
							string relRName(getRel(const_cast<char*> (attRight.c_str())));
							//							cout<<"relRName: " << relRName<<endl;
							rel relRight = relMap[relRName];
							if(relRcd.count(relRName) == 0){
								relRcd.insert(relRName);
								numerator *=   relRight.numTul;
							}
							denominator *= (1.0 - 1.0/max(relLeft.att[attLeft], relRight.att[attRight]));
							if(attDenominator.count(attLeft)==0) 
							attDenominator.insert(pair<string, double>(attLeft,1.0-1.0/max(relLeft.att[attLeft], relRight.att[attRight])));
							else
							attDenominator[attLeft]-=1.0/max(relLeft.att[attLeft], relRight.att[attRight]);
							
						}
					}

					curOr = curOr->rightOr; 	
				}
				double dominatorN = 1.0;
				    for (map<string,double> :: iterator it = attDenominator.begin(); it!=attDenominator.end() ; it++) {
					dominatorN *= it->second;        
    }
				resultN *= numerator*(1.0-dominatorN);
				result *= numerator * (1.0 - denominator);
								cout<<"denominator: "<< (1-denominator)<<endl;
								cout<<"denominatorN: "<<(1-dominatorN)<<endl;
				cout<<"estimateresult: "<<result<<endl;
				cout<<"======================="<<endl;
				cur = cur->rightAnd;
			}
			//			cout<<"end estimate"<<endl;
			return resultN;    
		}

		string Statistics::getRel(char *att){
			string atts(att);
			//cout<<"========="<<endl;
			//	cout<<"atts: "<<atts<<endl;
			for (map<string,rel> :: iterator it = relMap.begin(); it != relMap.end(); it++) {
				string rName = it->first;
				//		cout<<"rName " << rName<<endl;
				rel r = it->second;
				//		cout<<"relName size "<<r.att.size()<<endl;
				for(map<string,double> :: iterator it1 = r.att.begin(); it1 != r.att.end(); it1++)
					//			cout<<"att "<< it1->first<<endl;
					if (r.att.find(atts) != r.att.end()) {
						return rName;
					}
			}
			return "error";
		}

		/*
		   bool Statistics::CheckRel(char **relNames, int numToJoin){
		   set<string> relNameSet;
		   for (int i=0; i<numToJoin; i++) {
		   relNameSet.insert(relNames[i]);
		   }

		   FOR_SET(relNS, relNameSet)
		   FOR_MAP(sRel, numTul, relPartition)
		   if (sRel.find(relNs) != sRel.end()) {
		   FOR_SET(relPS, sRel)
		   if (strcmp(relNS, relPS) != 0) {
		   return false;
		   }
		   END_FOR
//check whether numTojoin == 0 in the end
//exclude {A,B,E,X}
numToJoin -= sRel.size();
}
END_FOR
END_FOR

return numToJoin==0;
}
		 */
